SOMATOGETHER V2 - SETUP NOTES

Included files:
- index.html: application structure
- style.css: responsive design
- script.js: Firebase authentication, profiles, subjects, sample quizzes, posts, friend requests and study groups
- firestore.rules: starter Firestore security rules

IMPORTANT BEFORE DEPLOYMENT
1. This is a prototype starter, not a fully audited production system.
2. Use the existing Firebase project. The Firebase web config in script.js is client configuration; Firestore Security Rules are essential.
3. In Firebase Console > Authentication > Sign-in method, enable Email/Password.
4. In Firebase Console > Firestore Database > Rules, review and publish firestore.rules.
5. Create/confirm the Firestore database in the same Firebase project.
6. Test registration, login, profile saving, posts, friend requests and groups with two separate test accounts.
7. The sample quiz bank is demonstration content, not a complete curriculum.
8. Soma AI is a placeholder. Actual AI requires a secure server/backend; never paste a private AI API key into script.js.
9. Test on a local server or Firebase Hosting. Opening index.html directly as a file may cause browser restrictions.

CURRICULUM
The starter subject/topic catalogue is organised into Primary, Secondary and College levels and can be expanded to match the exact curriculum and courses being targeted.

SECURITY / PRIVACY
The rules allow signed-in learners to read profiles because the friend lookup feature searches users by email. For a real public launch, replace this with a safer server-side learner discovery flow that does not expose all profile documents. Do not use real student personal data while testing.
