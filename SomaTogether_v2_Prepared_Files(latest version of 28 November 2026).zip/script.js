// ==========================================
// SOMATOGETHER - COMPLETE JAVASCRIPT
// PART 1: FIREBASE, AUTHENTICATION & PROFILE
// ==========================================

const firebaseConfig = {
  apiKey: "AIzaSyAxNzqen7cR0htPMgLVKoqp3tvsWhJJgUw",
  authDomain: "soma-together.firebaseapp.com",
  projectId: "soma-together",
  databaseURL: "https://soma-together-default-rtdb.europe-west1.firebasedatabase.app/",
  storageBucket: "soma-together.firebasestorage.app",
  messagingSenderId: "524938678671",
  appId: "1:524938678671:web:4fbf638f8f087f91a2fbfa",
  measurementId: "G-FWL42HCL1C"
};

if (!firebase.apps.length) {
  firebase.initializeApp(firebaseConfig);
}

const auth = firebase.auth();
const db = firebase.firestore();

const $ = id => document.getElementById(id);

let currentUser = null;
const ADMIN_UID = "vRpM3kpX5XPe9HH2j7iIwOB5g1d2";

function isAdmin() {
  return currentUser && currentUser.uid === ADMIN_UID;
}
let currentProfile = null;
let activeLevel = "Primary";
let activeSubject = null;
let unsubscribePosts = null;
let unsubscribeRequests = null;
let unsubscribeFriends = null;
let unsubscribeGroups = null;

function showMessage(message) {
  const box = $("authMessage");
  if (box) box.textContent = message;
  else alert(message);
}

function friendlyError(error) {
  console.error(error);
  const messages = {
    "auth/email-already-in-use": "That email is already registered.",
    "auth/invalid-email": "Enter a valid email address.",
    "auth/weak-password": "Use a stronger password.",
    "auth/user-not-found": "No account found with that email.",
    "auth/wrong-password": "Incorrect password.",
    "auth/invalid-credential": "Email or password is incorrect.",
    "permission-denied": "Permission denied. Check your Firestore rules."
  };
  return messages[error.code] || error.message || "Something went wrong.";
}

// REGISTRATION
if ($("registerForm")) {
  $("registerForm").addEventListener("submit", async event => {
    event.preventDefault();

    const name = $("regName").value.trim();
    const email = $("regEmail").value.trim();
    const password = $("regPassword").value;
    const level = $("regLevel").value;
    const learnerClass = $("regClass").value.trim();

    if (!name || !email || !password || !level) {
      showMessage("Please complete all required fields.");
      return;
    }

    try {
  const result = await auth.createUserWithEmailAndPassword(
    email,
    password
  );
  await result.user.sendEmailVerification();

  await db.collection("users").doc(result.user.uid).set({
    uid: result.user.uid,
    name: name,
    email: email,
    level: level,
    learnerClass: learnerClass,
    createdAt: firebase.firestore.FieldValue.serverTimestamp()
  });
      showMessage("Account created! Please check your email and verify it before logging in.");
    } catch (error) {
      showMessage(friendlyError(error));
    }
  });
}

// LOGIN
if ($("loginForm")) {
  $("loginForm").addEventListener("submit", async event => {
    event.preventDefault();

    const email = $("loginEmail").value.trim();
    const password = $("loginPassword").value;

    try {
      await auth.signInWithEmailAndPassword(email, password);
      console.log("LOGIN SUCCESS");
      showMessage("Login successful.");
    } catch (error) {
      console.error("LOGIN ERROR:", error);
      showMessage(friendlyError(error));
    }
  });
}

// PASSWORD RESET
if ($("resetPasswordBtn")) {
  $("resetPasswordBtn").addEventListener("click", async () => {
    const email = $("loginEmail").value.trim();

    if (!email) {
      showMessage("Enter your email first.");
      return;
    }

    try {
      await auth.sendPasswordResetEmail(email);
      showMessage("Password reset email sent.");
    } catch (error) {
      showMessage(friendlyError(error));
    }
  });
}

// LOGOUT
if ($("logoutBtn")) {
  $("logoutBtn").addEventListener("click", async () => {
    await auth.signOut();
  });
}
// ONLINE / OFFLINE PRESENCE
let presenceConnectionRef = null;
let presenceHandler = null;

function startOnlinePresence(user) {
  if (presenceConnectionRef && presenceHandler) {
    presenceConnectionRef.off("value", presenceHandler);
  }

  const connectedRef = firebase.database().ref(".info/connected");
  const statusRef = firebase.database().ref("status/" + user.uid);

  presenceConnectionRef = connectedRef;

  presenceHandler = async snapshot => {
    if (snapshot.val() !== true) return;

    try {
      await statusRef.onDisconnect().set({
        state: "offline",
        lastSeen: firebase.database.ServerValue.TIMESTAMP
      });

      await statusRef.set({
        state: "online",
        lastSeen: firebase.database.ServerValue.TIMESTAMP
      });
    } catch (error) {
      console.error("Presence error:", error);
    }
  };

  connectedRef.on("value", presenceHandler);
}
// LOAD PROFILE AND AUTHENTICATION STATE
auth.onAuthStateChanged(async user => {
  currentUser = user;

  if (!user) {
    currentProfile = null;

    if ($("authView")) $("authView").hidden = false;
    if ($("appView")) $("appView").hidden = true;
    if ($("userBar")) $("userBar").hidden = true;
if ($("resendVerificationBtn")) {
  $("resendVerificationBtn").hidden = false;
}
    return;
  }

  try {
    await user.reload();

if (!user.emailVerified) {
  currentProfile = null;

  if ($("authView")) $("authView").hidden = false;
  if ($("appView")) $("appView").hidden = true;
  if ($("userBar")) $("userBar").hidden = true;

  if ($("authMessage")) {
    $("authMessage").textContent =
      "Please verify your email before accessing SomaTogether. Check your inbox.";
  }

  return;
}
startOnlinePresence(user);
    const profileRef = db.collection("users").doc(user.uid);
    const profileDoc = await profileRef.get();

    if (profileDoc.exists) {
      currentProfile = profileDoc.data();
    } else {
      currentProfile = {
        uid: user.uid,
        name: user.email.split("@")[0],
        email: user.email,
        level: "Primary",
        learnerClass: ""
      };

      await profileRef.set(currentProfile);
    }

    if ($("authView")) $("authView").hidden = true;
    if ($("appView")) $("appView").hidden = false;
    if ($("userBar")) $("userBar").hidden = false;

    if ($("userName")) {
      $("userName").textContent = currentProfile.name;
    }

    if ($("welcomeTitle")) {
      $("welcomeTitle").textContent =
        "Welcome, " + currentProfile.name + "!";
    }

    displayProfile();
startCommunityListeners();
startFriendListeners();
startGroupListeners();
startMessaging();
const adminNavBtn = $("adminNavBtn");

if (adminNavBtn) {
  adminNavBtn.hidden = !isAdmin();
}

  } catch (error) {
    console.error("Profile loading failed:", error);
    showMessage(friendlyError(error));
  }
});

// PROFILE DISPLAY
function displayProfile() {
  if (!currentProfile) return;

  if ($("profileSummary")) {
    $("profileSummary").textContent =
      currentProfile.name + " | " +
      currentProfile.level + " | " +
      (currentProfile.learnerClass || "Class not specified");
  }

  if ($("profileName")) {
    $("profileName").value = currentProfile.name || "";
  }

  if ($("profileLevel")) {
    $("profileLevel").value = currentProfile.level || "Primary";
  }

  if ($("profileClass")) {
    $("profileClass").value = currentProfile.learnerClass || "";
  }
}

// OPEN PROFILE EDITOR
if ($("editProfileBtn")) {
  $("editProfileBtn").addEventListener("click", () => {
    if ($("profileEditor")) {
      $("profileEditor").hidden = false;
    }
  });
}

// SAVE PROFILE
if ($("profileForm")) {
  $("profileForm").addEventListener("submit", async event => {
    event.preventDefault();

    if (!currentUser) return;

    const name = $("profileName").value.trim();
    const level = $("profileLevel").value;
    const learnerClass = $("profileClass").value.trim();

    if (!name || !level) {
      alert("Name and level are required.");
      return;
    }

    try {
      const updatedProfile = {
        name,
        level,
        learnerClass,
        updatedAt: firebase.firestore.FieldValue.serverTimestamp()
      };

      await db.collection("users")
        .doc(currentUser.uid)
        .update(updatedProfile);

      currentProfile = {
        ...currentProfile,
        name,
        level,
        learnerClass
      };

      displayProfile();

      if ($("userName")) $("userName").textContent = name;
      if ($("welcomeTitle")) {
        $("welcomeTitle").textContent = "Welcome, " + name + "!";
      }

      if ($("profileEditor")) {
        $("profileEditor").hidden = true;
      }

      alert("Profile updated successfully.");

    } catch (error) {
      alert("Profile saving failed: " + friendlyError(error));
    }
  });
}
// ==========================================
// PART 2: SUBJECTS AND LEARNING TOPICS
// ==========================================

const subjectCatalog = {
  Primary: [
    "Mathematics",
    "English",
    "Kiswahili",
    "Science and Technology",
    "Social Studies",
    "CRE",
    "Agriculture",
    "Creative Arts",
    "Physical Education"
  ],

  Secondary: [
    "Mathematics",
    "English",
    "Kiswahili",
    "Biology",
    "Chemistry",
    "Physics",
    "Geography",
    "History",
    "CRE",
    "Business Studies",
    "Computer Studies",
    "Agriculture",
    "Home Science"
  ],

  College: [
    "ICT",
    "Computer Science",
    "Programming",
    "Web Development",
    "Database Management",
    "Networking",
    "Cybersecurity",
    "Mathematics",
    "Communication Skills",
    "Entrepreneurship",
    "Operating Systems",
    "Basic Electronics"
  ]
};

const topicCatalog = {
  Mathematics: [
    "Algebra",
    "Numbers",
    "Fractions",
    "Decimals",
    "Percentages",
    "Geometry",
    "Measurements",
    "Statistics",
    "Probability",
    "Equations"
  ],

  English: [
    "Grammar",
    "Comprehension",
    "Composition",
    "Vocabulary",
    "Pronunciation",
    "Literature",
    "Creative Writing"
  ],

  Kiswahili: [
    "Sarufi",
    "Ufahamu",
    "Insha",
    "Fasihi",
    "Msamiati",
    "Matumizi ya Lugha"
  ],

  Biology: [
    "Cell Biology",
    "Nutrition",
    "Respiration",
    "Transport",
    "Reproduction",
    "Ecology",
    "Classification"
  ],

  Chemistry: [
    "Atoms and Elements",
    "Chemical Bonding",
    "Acids and Bases",
    "Salts",
    "Periodic Table",
    "Chemical Reactions"
  ],

  Physics: [
    "Measurement",
    "Forces",
    "Energy",
    "Electricity",
    "Waves",
    "Light",
    "Magnetism"
  ],

  ICT: [
    "Computer Fundamentals",
    "Hardware",
    "Software",
    "Operating Systems",
    "Networking",
    "Internet",
    "Cybersecurity",
    "Word Processing",
    "Spreadsheets",
    "Databases"
  ],

  "Computer Science": [
    "Introduction to Computing",
    "Algorithms",
    "Programming",
    "Data Structures",
    "Databases",
    "Computer Networks",
    "Software Engineering"
  ],

  Programming: [
    "Introduction to Programming",
    "Variables",
    "Data Types",
    "Conditions",
    "Loops",
    "Functions",
    "Arrays",
    "Object-Oriented Programming"
  ],

  "Web Development": [
    "HTML",
    "CSS",
    "JavaScript",
    "Responsive Design",
    "Frontend Development",
    "Backend Development"
  ],

  Networking: [
    "Network Fundamentals",
    "LAN and WAN",
    "IP Addresses",
    "Network Devices",
    "Network Security"
  ],

  Cybersecurity: [
    "Security Fundamentals",
    "Passwords and Authentication",
    "Malware Awareness",
    "Online Safety",
    "Data Protection"
  ],

  "Basic Electronics": [
    "Electrical Quantities",
    "Resistors",
    "Capacitors",
    "Diodes",
    "Transistors",
    "Basic Circuits"
  ],

  "Operating Systems": [
    "Introduction to Operating Systems",
    "Process Management",
    "Memory Management",
    "File Management",
    "Operating System Types"
  ]
};

// ADD TOPICS FOR OTHER SUBJECTS
const generalTopics = [
  "Introduction",
  "Basic Concepts",
  "Key Definitions",
  "Principles",
  "Applications",
  "Revision"
];

function getTopics(subject) {
  return topicCatalog[subject] || generalTopics;
}

// DISPLAY SUBJECTS
function displaySubjects() {
  const grid = $("subjectGrid");
  if (!grid) return;

  const subjects = subjectCatalog[activeLevel] || [];

  grid.innerHTML = "";

  subjects.forEach(subject => {
    const card = document.createElement("button");

    card.type = "button";
    card.className = "subject-card";
    card.textContent = subject;

    card.addEventListener("click", () => {
      openSubject(subject);
    });

    grid.appendChild(card);
  });
}

// OPEN A SUBJECT
function openSubject(subject) {
  activeSubject = subject;

  const panel = $("topicPanel");
  const title = $("topicTitle");
  const list = $("topicList");

  if (!panel || !title || !list) return;

  title.textContent = subject + " Topics";
  list.innerHTML = "";

  getTopics(subject).forEach(topic => {
    const item = document.createElement("button");

    item.type = "button";
    item.className = "topic-item";
    item.textContent = topic;

    item.addEventListener("click", () => {
      openTopic(subject, topic);
    });

    list.appendChild(item);
  });

  panel.hidden = false;
}

// OPEN A TOPIC
function openTopic(subject, topic) {
  const panel = $("topicPanel");
  if (!panel) return;

  let notes = {
    Algebra:
      "Algebra is a branch of mathematics that uses letters and symbols to represent numbers. Example: x + 3 = 7. Subtract 3 from both sides to find x = 4.",

    Fractions:
      "A fraction represents part of a whole. It has a numerator on top and a denominator below. Example: 1/2 means one out of two equal parts.",

    Percentages:
      "A percentage is a number expressed out of 100. Example: 25% means 25 out of every 100.",

    Geometry:
      "Geometry is the study of shapes, sizes, angles and positions. Common shapes include triangles, circles, rectangles and squares.",

    Variables:
      "A variable is a symbol, usually a letter, that represents a value. Example: in x + 5 = 10, x is the variable.",

    Loops:
      "A loop repeats a block of instructions while a condition is true or for a specified number of times.",

    Functions:
      "A function is a reusable block of code that performs a particular task. Functions help organize programs.",

    HTML:
      "HTML stands for HyperText Markup Language. It provides the structure of a web page using elements such as headings, paragraphs and links.",

    CSS:
      "CSS stands for Cascading Style Sheets. It controls the appearance of web pages, including colours, spacing and layout.",

    JavaScript:
      "JavaScript is a programming language used to make websites interactive. It can respond to clicks, validate forms and update page content.",

    "Computer Fundamentals":
      "Computer fundamentals introduce the basic parts of a computer, how data is processed and how people interact with computer systems.",

    "Operating Systems":
      "An operating system manages computer hardware and software resources. Examples include Windows, Linux, Android and macOS.",

    "Network Fundamentals":
      "Computer networking connects devices so they can communicate and share information and resources."
  };

  const content = notes[topic] ||
    topic + " is an important topic in " + subject +
    ". Study its key definitions, principles, examples and practical applications.";

  let oldContent = $("topicNotes");

  if (!oldContent) {
    oldContent = document.createElement("div");
    oldContent.id = "topicNotes";
    oldContent.className = "topic-notes";
    panel.appendChild(oldContent);
  }

  oldContent.innerHTML = "";

  const heading = document.createElement("h3");
  heading.textContent = topic;

  const paragraph = document.createElement("p");
  paragraph.textContent = content;

  oldContent.appendChild(heading);
  oldContent.appendChild(paragraph);

  oldContent.scrollIntoView({
    behavior: "smooth",
    block: "nearest"
  });
}

// LEVEL FILTER
if ($("levelFilter")) {
  $("levelFilter").addEventListener("change", event => {
    activeLevel = event.target.value || "Primary";
    displaySubjects();
  });
}

// CLOSE TOPICS
if ($("closeTopics")) {
  $("closeTopics").addEventListener("click", () => {
    if ($("topicPanel")) $("topicPanel").hidden = true;
  });
}

// NAVIGATION
document.querySelectorAll(".nav-btn").forEach(button => {
  button.addEventListener("click", () => {
    const target = button.dataset.view;

    document.querySelectorAll("#appView .view").forEach(view => {
      view.hidden = view.id !== target;
    });

    document.querySelectorAll(".nav-btn").forEach(nav => {
      nav.classList.remove("active");
    });

    button.classList.add("active");

    if (target === "learnView") {
      displaySubjects();
    }
    if (target === "adminView") {
  loadAdminDashboard();
}
  });
});


// INITIAL SUBJECT DISPLAY
displaySubjects();
// ==========================================
// PART 3: QUIZZES AND SCORING
// ==========================================

const quizBank = {
  Mathematics: [
    {
      question: "Solve: 5 + 7 = ?",
      options: ["10", "11", "12", "13"],
      answer: 2,
      explanation: "5 + 7 = 12."
    },
    {
      question: "What is 20% of 100?",
      options: ["10", "20", "30", "40"],
      answer: 1,
      explanation: "20% of 100 is 20."
    },
    {
      question: "Solve: x + 4 = 9.",
      options: ["3", "4", "5", "6"],
      answer: 2,
      explanation: "Subtract 4 from both sides. x = 5."
    },
    {
      question: "What is the square of 6?",
      options: ["12", "24", "36", "42"],
      answer: 2,
      explanation: "6 × 6 = 36."
    }
  ],

  English: [
    {
      question: "Which word is a noun?",
      options: ["Run", "Beautiful", "Teacher", "Quickly"],
      answer: 2,
      explanation: "A teacher is a person, so it is a noun."
    },
    {
      question: "Choose the correct plural of child.",
      options: ["Childs", "Children", "Childes", "Childrens"],
      answer: 1,
      explanation: "The plural of child is children."
    },
    {
      question: "Which word is an adjective?",
      options: ["Happiness", "Beautiful", "Run", "Slowly"],
      answer: 1,
      explanation: "Beautiful describes a noun."
    }
  ],

  Biology: [
    {
      question: "What is the basic unit of life?",
      options: ["Tissue", "Organ", "Cell", "System"],
      answer: 2,
      explanation: "The cell is the basic structural and functional unit of life."
    },
    {
      question: "Which organ pumps blood?",
      options: ["Lungs", "Heart", "Kidney", "Liver"],
      answer: 1,
      explanation: "The heart pumps blood around the body."
    },
    {
      question: "Which process do green plants use to make food?",
      options: ["Respiration", "Digestion", "Photosynthesis", "Excretion"],
      answer: 2,
      explanation: "Green plants make food through photosynthesis."
    }
  ],

  ICT: [
    {
      question: "What does CPU stand for?",
      options: [
        "Central Processing Unit",
        "Computer Personal Unit",
        "Central Program Utility",
        "Control Processing User"
      ],
      answer: 0,
      explanation: "CPU stands for Central Processing Unit."
    },
    {
      question: "Which one is an input device?",
      options: ["Monitor", "Printer", "Keyboard", "Speaker"],
      answer: 2,
      explanation: "A keyboard is used to enter data into a computer."
    },
    {
      question: "Which of these is an operating system?",
      options: ["Microsoft Word", "Linux", "Google Chrome", "HTML"],
      answer: 1,
      explanation: "Linux is an operating system."
    }
  ],

  Programming: [
    {
      question: "Which symbol is commonly used for assignment in JavaScript?",
      options: ["=", "==", "!=", ">"],
      answer: 0,
      explanation: "The single equals sign assigns a value."
    },
    {
      question: "Which keyword declares a variable in JavaScript?",
      options: ["print", "let", "echo", "write"],
      answer: 1,
      explanation: "let declares a block-scoped variable."
    },
    {
      question: "Which data type represents true or false?",
      options: ["String", "Number", "Boolean", "Array"],
      answer: 2,
      explanation: "Boolean values are true or false."
    }
  ],

  "Computer Science": [
    {
      question: "What is an algorithm?",
      options: [
        "A computer screen",
        "A step-by-step solution to a problem",
        "A type of printer",
        "A programming error"
      ],
      answer: 1,
      explanation: "An algorithm is a sequence of steps for solving a problem."
    },
    {
      question: "Which one is a programming language?",
      options: ["HTML", "Python", "Wi-Fi", "CPU"],
      answer: 1,
      explanation: "Python is a programming language."
    }
  ]
};

let currentQuiz = [];
let currentQuestionIndex = 0;
let quizScore = 0;
let quizAnswers = [];

function getQuizQuestions(subject) {
  const questions = quizBank[subject];

  if (questions && questions.length) {
    return [...questions];
  }

  return [
    {
      question: "Why is " + subject + " important?",
      options: [
        "It develops knowledge and skills",
        "It has no use",
        "It prevents learning",
        "It replaces every other subject"
      ],
      answer: 0,
      explanation: subject + " helps learners develop useful knowledge and skills."
    }
  ];
}

// START QUIZ
if ($("startQuizBtn")) {
  $("startQuizBtn").addEventListener("click", () => {
    const subject = $("quizSubject").value;

    if (!subject) {
      alert("Please select a subject first.");
      return;
    }

    currentQuiz = getQuizQuestions(subject);
    currentQuestionIndex = 0;
    quizScore = 0;
    quizAnswers = [];

    showQuizQuestion();
  });
}

// DISPLAY QUESTION
function showQuizQuestion() {
  const area = $("quizArea");
  if (!area) return;

  if (currentQuestionIndex >= currentQuiz.length) {
    showQuizResults();
    return;
  }

  const question = currentQuiz[currentQuestionIndex];

  area.innerHTML = "";

  const heading = document.createElement("h3");
  heading.textContent =
    "Question " + (currentQuestionIndex + 1) +
    " of " + currentQuiz.length;

  const questionText = document.createElement("p");
  questionText.textContent = question.question;

  const optionsContainer = document.createElement("div");
  optionsContainer.className = "quiz-options";

  question.options.forEach((option, index) => {
    const button = document.createElement("button");

    button.type = "button";
    button.className = "quiz-option";
    button.textContent = option;

    button.addEventListener("click", () => {
      selectQuizAnswer(index);
    });

    optionsContainer.appendChild(button);
  });

  area.appendChild(heading);
  area.appendChild(questionText);
  area.appendChild(optionsContainer);
}

// SELECT ANSWER
function selectQuizAnswer(selectedIndex) {
  const question = currentQuiz[currentQuestionIndex];
  const correct = selectedIndex === question.answer;

  if (correct) {
    quizScore++;
  }

  quizAnswers.push({
    question: question.question,
    selected: question.options[selectedIndex],
    correct: question.options[question.answer],
    isCorrect: correct
  });

  const area = $("quizArea");
  if (!area) return;

  const feedback = document.createElement("p");

  feedback.textContent = correct
    ? "Correct! " + question.explanation
    : "Not quite. Correct answer: " +
      question.options[question.answer] +
      ". " + question.explanation;

  feedback.className = correct
    ? "quiz-correct"
    : "quiz-incorrect";

  const nextButton = document.createElement("button");

  nextButton.type = "button";
  nextButton.textContent =
    currentQuestionIndex === currentQuiz.length - 1
      ? "See Results"
      : "Next Question";

  nextButton.addEventListener("click", () => {
    currentQuestionIndex++;
    showQuizQuestion();
  });

  area.innerHTML = "";
  area.appendChild(feedback);
  area.appendChild(nextButton);
}

// SHOW RESULTS
function showQuizResults() {
  const area = $("quizArea");
  if (!area) return;

  const percentage = Math.round(
    (quizScore / currentQuiz.length) * 100
  );

  area.innerHTML = "";

  const heading = document.createElement("h2");
  heading.textContent = "Quiz Completed!";

  const score = document.createElement("p");
  score.textContent =
    "Your score: " + quizScore +
    " out of " + currentQuiz.length;

  const result = document.createElement("p");
  result.textContent = "Percentage: " + percentage + "%";

  const message = document.createElement("p");

  if (percentage >= 80) {
    message.textContent = "Excellent work! Keep learning.";
  } else if (percentage >= 50) {
    message.textContent = "Good effort. Keep practising.";
  } else {
    message.textContent = "Keep studying. You can improve.";
  }

  const retryButton = document.createElement("button");
  retryButton.type = "button";
  retryButton.textContent = "Try Again";

  retryButton.addEventListener("click", () => {
    currentQuestionIndex = 0;
    quizScore = 0;
    quizAnswers = [];
    showQuizQuestion();
  });

  area.appendChild(heading);
  area.appendChild(score);
  area.appendChild(result);
  area.appendChild(message);
  area.appendChild(retryButton);
}
// ==========================================
// PART 4: COMMUNITY POSTS AND FRIEND REQUESTS
// ==========================================

// PUBLISH COMMUNITY POST
if ($("postForm")) {
  $("postForm").addEventListener("submit", async event => {
    event.preventDefault();

    if (!currentUser || !currentProfile) {
      alert("Please log in first.");
      return;
    }

    const text = $("postText").value.trim();

    if (!text) {
      alert("Write something before publishing.");
      return;
    }

    try {
      await db.collection("posts").add({
        text: text,
        authorUid: currentUser.uid,
        authorName: currentProfile.name || "Learner",
        level: currentProfile.level || "Primary",
        createdAt: firebase.firestore.FieldValue.serverTimestamp()
      });

      $("postText").value = "";
      alert("Your post has been published!");

    } catch (error) {
      alert("Post could not be published: " + friendlyError(error));
    }
  });
}

// LOAD COMMUNITY POSTS
function startCommunityListeners() {
  if (unsubscribePosts) unsubscribePosts();

  unsubscribePosts = db.collection("posts")
    .orderBy("createdAt", "desc")
    .limit(50)
    .onSnapshot(snapshot => {
      const feed = $("feed");
      if (!feed) return;

      feed.innerHTML = "";

      if (snapshot.empty) {
        feed.textContent = "No community posts yet. Be the first to share!";
        return;
      }

      snapshot.forEach(doc => {
        const post = doc.data();

        const card = document.createElement("article");
        card.className = "post-card";

        const author = document.createElement("h3");
        author.textContent = post.authorName || "Learner";

        const level = document.createElement("small");
        level.textContent = post.level || "Learner";

        const content = document.createElement("p");
        content.textContent = post.text || "";

        card.appendChild(author);
        card.appendChild(level);
        card.appendChild(content);

        if (post.authorUid === currentUser.uid) {
          const deleteButton = document.createElement("button");
          deleteButton.type = "button";
          deleteButton.textContent = "Delete post";

          deleteButton.addEventListener("click", async () => {
            if (!confirm("Delete this post?")) return;

            try {
              await db.collection("posts").doc(doc.id).delete();
            } catch (error) {
              alert("Could not delete post: " + friendlyError(error));
            }
          });

          card.appendChild(deleteButton);
        }

        feed.appendChild(card);
      });

    }, error => {
      console.error("Community loading error:", error);
      const feed = $("feed");
      if (feed) feed.textContent =
        "Unable to load posts: " + friendlyError(error);
    });
}

// SEND FRIEND REQUEST
if ($("friendForm")) {
  $("friendForm").addEventListener("submit", async event => {
    event.preventDefault();

    if (!currentUser || !currentProfile) return;

    const email = $("friendEmail").value.trim().toLowerCase();

    if (!email) {
      alert("Enter the learner's email.");
      return;
    }

    if (email === currentUser.email.toLowerCase()) {
      alert("You cannot send a friend request to yourself.");
      return;
    }

    try {
      const users = await db.collection("users")
        .where("email", "==", email)
        .limit(1)
        .get();

      if (users.empty) {
        alert("No learner account found with that email.");
        return;
      }

      const recipient = users.docs[0];

      const existing = await db.collection("friendRequests")
        .where("senderUid", "==", currentUser.uid)
        .where("receiverUid", "==", recipient.id)
        .get();

      if (!existing.empty) {
        alert("You have already sent a request to this learner.");
        return;
      }

      await db.collection("friendRequests").add({
        senderUid: currentUser.uid,
        senderName: currentProfile.name || "Learner",
        receiverUid: recipient.id,
        receiverEmail: email,
        status: "pending",
        createdAt: firebase.firestore.FieldValue.serverTimestamp()
      });

      $("friendEmail").value = "";
      alert("Friend request sent!");

    } catch (error) {
      alert("Friend request failed: " + friendlyError(error));
    }
  });
}

// LOAD INCOMING FRIEND REQUESTS
function startFriendListeners() {
  if (unsubscribeRequests) unsubscribeRequests();
  if (unsubscribeFriends) unsubscribeFriends();

  unsubscribeRequests = db.collection("friendRequests")
    .where("receiverUid", "==", currentUser.uid)
    .where("status", "==", "pending")
    .onSnapshot(snapshot => {
      const container = $("incomingRequests");
      if (!container) return;

      container.innerHTML = "";

      if (snapshot.empty) {
        container.textContent = "No pending friend requests.";
        return;
      }

      snapshot.forEach(doc => {
        const request = doc.data();

        const card = document.createElement("div");
        card.className = "friend-request";

        const name = document.createElement("p");
        name.textContent =
          (request.senderName || "Learner") + " wants to connect.";

        const acceptButton = document.createElement("button");
        acceptButton.type = "button";
        acceptButton.textContent = "Accept";

        acceptButton.addEventListener("click", async () => {
          try {
            await db.collection("friendRequests")
              .doc(doc.id)
              .update({ status: "accepted" });
const friendshipId = [currentUser.uid, request.senderUid]
  .sort()
  .join("_");

await db.collection("friendships").doc(friendshipId).set({
  users: [currentUser.uid, request.senderUid],
  createdAt: firebase.firestore.FieldValue.serverTimestamp()
});

            alert("Friend request accepted!");

          } catch (error) {
            alert("Could not accept request: " + friendlyError(error));
          }
        });

        const declineButton = document.createElement("button");
        declineButton.type = "button";
        declineButton.textContent = "Decline";

        declineButton.addEventListener("click", async () => {
          try {
            await db.collection("friendRequests")
              .doc(doc.id)
              .update({ status: "declined" });
          } catch (error) {
            alert("Could not decline request: " + friendlyError(error));
          }
        });

        card.appendChild(name);
        card.appendChild(acceptButton);
        card.appendChild(declineButton);

        container.appendChild(card);
      });

    }, error => {
      console.error("Request loading error:", error);
    });

  // LOAD FRIENDS
  unsubscribeFriends = db.collection("friendships")
    .where("users", "array-contains", currentUser.uid)
    .onSnapshot(async snapshot => {
      const container = $("friendsList");
      if (!container) return;

      container.innerHTML = "";

      if (snapshot.empty) {
        container.textContent = "You have no connections yet.";
        return;
      }

      for (const doc of snapshot.docs) {
        const friendship = doc.data();

        const friendUid = (friendship.users || [])
          .find(uid => uid !== currentUser.uid);

        if (!friendUid) continue;

        try {
          const friendDoc = await db.collection("users")
            .doc(friendUid)
            .get();

          const friend = friendDoc.data();

          const item = document.createElement("p");
          item.textContent = friend
            ? friend.name + " (" + friend.email + ")"
            : "Connected learner";

          container.appendChild(item);

        } catch (error) {
          console.error("Could not load friend profile:", error);
        }
      }
    }, error => {
      console.error("Friends loading error:", error);
    });
}
// ==========================================
// PART 5: STUDY GROUPS
// ==========================================

// CREATE STUDY GROUP
if ($("groupForm")) {
  $("groupForm").addEventListener("submit", async event => {
    event.preventDefault();

    if (!currentUser || !currentProfile) {
      alert("Please log in first.");
      return;
    }

    const name = $("groupName").value.trim();
    const subject = $("groupSubject").value;

    if (!name || !subject) {
      alert("Enter a group name and select a subject.");
      return;
    }

    try {
      await db.collection("studyGroups").add({
        name: name,
        subject: subject,
        creatorUid: currentUser.uid,
        creatorName: currentProfile.name || "Learner",
        members: [currentUser.uid],
        createdAt: firebase.firestore.FieldValue.serverTimestamp()
      });

      $("groupName").value = "";
      alert("Study group created!");

    } catch (error) {
      alert("Group creation failed: " + friendlyError(error));
    }
  });
}

// LOAD STUDY GROUPS
function startGroupListeners() {
  if (unsubscribeGroups) unsubscribeGroups();

  unsubscribeGroups = db.collection("studyGroups")
    .orderBy("createdAt", "desc")
    .limit(50)
    .onSnapshot(snapshot => {
      const container = $("groupsList");
      if (!container) return;

      container.innerHTML = "";

      if (snapshot.empty) {
        container.textContent =
          "No study groups yet. Create the first one!";
        return;
      }

      snapshot.forEach(doc => {
        const group = doc.data();

        const card = document.createElement("article");
        card.className = "group-card";

        const heading = document.createElement("h3");
        heading.textContent = group.name || "Study Group";

        const subject = document.createElement("p");
        subject.textContent = "Subject: " + (group.subject || "General");

        const creator = document.createElement("small");
        creator.textContent =
          "Created by " + (group.creatorName || "Learner");

        const members = Array.isArray(group.members)
          ? group.members
          : [];

        const count = document.createElement("p");
        count.textContent = "Members: " + members.length;

        card.appendChild(heading);
        card.appendChild(subject);
        card.appendChild(creator);
        card.appendChild(count);

        if (members.includes(currentUser.uid)) {
          const joined = document.createElement("p");
          joined.textContent = "You are a member.";
          card.appendChild(joined);
        } else {
          const joinButton = document.createElement("button");
          joinButton.type = "button";
          joinButton.textContent = "Join Group";

          joinButton.addEventListener("click", async () => {
            try {
              await db.collection("studyGroups")
                .doc(doc.id)
                .update({
                  members: firebase.firestore.FieldValue.arrayUnion(
                    currentUser.uid
                  )
                });

              alert("You joined the study group!");

            } catch (error) {
              alert("Could not join group: " + friendlyError(error));
            }
          });

          card.appendChild(joinButton);
        }

        container.appendChild(card);
      });

    }, error => {
      console.error("Study groups loading error:", error);
      const container = $("groupsList");
      if (container) {
        container.textContent =
          "Unable to load groups: " + friendlyError(error);
      }
    });
}

// ==========================================
// PART 6: FINAL INITIALIZATION
// ==========================================

document.addEventListener("DOMContentLoaded", () => {
  if ($("levelFilter")) {
    activeLevel = $("levelFilter").value || "Primary";
  }

  displaySubjects();

  console.log("SomaTogether JavaScript loaded successfully.");
});// ==========================================
// SOMATOGETHER - BASIC LEARNING ASSISTANT
// ==========================================

const assistantForm = document.getElementById("assistantForm");
const assistantInput = document.getElementById("assistantInput");
const assistantChat = document.getElementById("assistantChat");
const assistantStatus = document.getElementById("assistantStatus");

function addAssistantMessage(message, sender) {
  const messageDiv = document.createElement("div");

  messageDiv.className = sender === "user"
    ? "user-message"
    : "assistant-message";

  messageDiv.textContent = message;
  messageDiv.style.padding = "12px";
  messageDiv.style.margin = "10px 0";
  messageDiv.style.borderRadius = "10px";
  messageDiv.style.whiteSpace = "pre-wrap";

  if (sender === "user") {
    messageDiv.style.background = "#e9e7ff";
    messageDiv.style.marginLeft = "15%";
  } else {
    messageDiv.style.background = "#f0f7ff";
    messageDiv.style.marginRight = "15%";
  }

  assistantChat.appendChild(messageDiv);
  assistantChat.scrollTop = assistantChat.scrollHeight;
}

function getSomaAnswer(question) {
  const q = question.toLowerCase();

  if (q.includes("hello") || q.includes("hi") || q.includes("hey")) {
    return "Hello! Welcome to SomaTogether. What subject are you studying today?";
  }

  // MATHEMATICS
  if (q.includes("algebra")) {
    return "Algebra is a branch of Mathematics that uses letters and symbols to represent numbers.\n\nExample:\nIf x + 5 = 12, subtract 5 from both sides.\nTherefore, x = 7.";
  }

  if (q.includes("fraction")) {
    return "A fraction represents part of a whole.\n\nExample: 1/2 means one part out of two equal parts.\n\nTo add fractions with the same denominator, add their numerators and keep the denominator.";
  }

  if (q.includes("mathematics") || q.includes("math")) {
    return "Mathematics is the study of numbers, shapes, patterns and calculations. I can help with algebra, fractions, geometry and arithmetic.";
  }

  // BIOLOGY
  if (q.includes("photosynthesis")) {
    return "Photosynthesis is the process by which green plants use sunlight, water and carbon dioxide to make glucose (food). Oxygen is released during this process.";
  }

  if (q.includes("cell")) {
    return "A cell is the basic structural and functional unit of life.\n\nExamples of cell parts include the nucleus, cytoplasm and cell membrane.";
  }

  if (q.includes("biology")) {
    return "Biology is the scientific study of living organisms, including plants, animals and microorganisms.";
  }

  if (q.includes("respiration")) {
    return "Cellular respiration is the process by which cells release energy from glucose. In aerobic respiration, oxygen is used.";
  }

  // CHEMISTRY
  if (q.includes("atom")) {
    return "An atom is the smallest unit of an element that retains its chemical properties. It contains protons, neutrons and electrons.";
  }

  if (q.includes("periodic table")) {
    return "The periodic table organizes chemical elements according to their atomic numbers and repeating chemical properties.";
  }

  if (q.includes("chemistry")) {
    return "Chemistry is the study of matter, its properties, composition and the changes it undergoes.";
  }

  if (q.includes("acid")) {
    return "An acid is a substance that donates hydrogen ions in aqueous solution. Acids have a pH below 7.";
  }

  // PHYSICS
  if (q.includes("newton")) {
    return "Newton's laws of motion describe how forces affect the movement of objects. His second law is commonly written as F = ma.";
  }

  if (q.includes("force")) {
    return "Force is a push or pull that can change an object's motion or shape. Its SI unit is the newton (N).";
  }

  if (q.includes("physics")) {
    return "Physics is the study of matter, energy, motion and forces. It helps explain how the physical world works.";
  }

  if (q.includes("electricity")) {
    return "Electricity involves the presence and movement of electric charges. Electric current is measured in amperes (A).";
  }

  // COMPUTER STUDIES AND ICT
  if (q.includes("operating system")) {
    return "An operating system is system software that manages computer hardware and software resources.\n\nExamples include Windows, Linux, Android and macOS.";
  }

  if (q.includes("network")) {
    return "A computer network is a group of connected devices that communicate and share resources. Examples include LAN and WAN.";
  }

  if (q.includes("computer")) {
    return "A computer is an electronic device that accepts data, processes it, stores it and produces information.";
  }

  if (q.includes("ict")) {
    return "ICT stands for Information and Communication Technology. It involves using computers, networks and digital tools to process and communicate information.";
  }

  if (q.includes("hardware")) {
    return "Computer hardware refers to the physical parts of a computer, such as the keyboard, monitor, motherboard and processor.";
  }

  if (q.includes("software")) {
    return "Software is a set of programs and instructions that tell a computer what to do. Examples include operating systems and web browsers.";
  }

  // PROGRAMMING AND WEB DEVELOPMENT
  if (q.includes("javascript")) {
    return "JavaScript is a programming language commonly used to make websites interactive. It can respond to clicks, validate forms and update webpage content.";
  }

  if (q.includes("html")) {
    return "HTML stands for HyperText Markup Language. It is used to structure content on web pages, including headings, paragraphs, images and links.";
  }

  if (q.includes("css")) {
    return "CSS stands for Cascading Style Sheets. It controls the appearance of web pages, including colours, fonts, spacing and layouts.";
  }

  if (q.includes("programming") || q.includes("coding")) {
    return "Programming is the process of writing instructions that tell a computer what to do.\n\nExamples of programming languages include C, JavaScript, Python and Java.";
  }

  // ENGLISH
  if (q.includes("noun")) {
    return "A noun is a word used to name a person, place, animal or thing.\n\nExamples: teacher, school, dog and book.";
  }

  if (q.includes("verb")) {
    return "A verb is a word that expresses an action or state.\n\nExamples: run, read, write and think.";
  }

  if (q.includes("english")) {
    return "English helps us communicate through speaking, listening, reading and writing. I can help with grammar, nouns, verbs and sentence construction.";
  }

  // STUDY SUPPORT
  if (q.includes("study") || q.includes("revision")) {
    return "Here are some useful study tips:\n\n1. Set a clear study goal.\n2. Study one topic at a time.\n3. Write short notes.\n4. Practise questions.\n5. Review what you learned.";
  }

  if (q.includes("help")) {
    return "I can currently help with:\n\n• Mathematics\n• Biology\n• Chemistry\n• Physics\n• English\n• ICT and Computer Studies\n• HTML, CSS and JavaScript\n• Programming basics\n• Study tips\n\nAsk me about any of these topics!";
  }

  return "That's an interesting question! I don't have a prepared explanation for that topic yet. Try asking about Mathematics, Biology, Chemistry, Physics, English, ICT or Programming.";
}
// SOMA ASSISTANT SUBMIT HANDLER

if (assistantForm) {
  assistantForm.addEventListener("submit", function(event) {
    event.preventDefault();

    const question = assistantInput.value.trim();

    if (!question) return;

    addAssistantMessage(question, "user");

    const answer = getSomaAnswer(question);

    addAssistantMessage(answer, "assistant");

    assistantInput.value = "";
    assistantStatus.textContent = "Soma Assistant replied.";
  });
}

// ==========================================
// SOMATOGETHER - REAL-TIME MESSAGING
// ==========================================

let activeChatId = null;
let unsubscribeChatMessages = null;
let unsubscribeChatFriends = null;

// LOAD FRIENDS INTO MESSAGES
// LOAD ADMIN DASHBOARD
async function loadAdminDashboard() {
  if (!isAdmin()) return;

  const feedbackList = $("adminFeedbackList");
  const deletionList = $("adminDeletionList");
  const status = $("adminStatus");

  status.textContent = "Loading submissions...";

  try {
    const feedback = await db.collection("feedback").get();
    const deletions = await db.collection("deletionRequests").get();

    feedbackList.textContent = "";
    deletionList.textContent = "";

    if (feedback.empty) {
      feedbackList.textContent = "No feedback submissions yet.";
    } else {
feedback.forEach(doc => {
  const data = doc.data();
  const item = document.createElement("div");
  
  const details = document.createElement("p");
  details.textContent =
    data.type + ": " + data.message +
    " | User ID: " + data.userId +
    " | Status: " + data.status;
  
  item.appendChild(details);
  
  if (data.status === "new") {
    const reviewBtn = document.createElement("button");
    reviewBtn.textContent = "Mark as Reviewed";
    
    reviewBtn.addEventListener("click", async () => {
      try {
        await db.collection("feedback")
          .doc(doc.id)
          .update({ status: "reviewed" });
        
        await loadAdminDashboard();
      } catch (error) {
        status.textContent =
          "Update failed: " + error.message;
      }
    });
    
    item.appendChild(reviewBtn);
  }
  
  feedbackList.appendChild(item);
});
    }

    if (deletions.empty) {
      deletionList.textContent = "No deletion requests yet.";
    } else {
deletions.forEach(doc => {
  const data = doc.data();
  const item = document.createElement("div");
  
  const details = document.createElement("p");
  details.textContent =
    "User ID: " + data.userId +
    " | Status: " + data.status;
  
  item.appendChild(details);
  
  if (data.status === "pending") {
    const reviewBtn = document.createElement("button");
    reviewBtn.textContent = "Mark as Reviewed";
    
    reviewBtn.addEventListener("click", async () => {
      try {
        await db.collection("deletionRequests")
          .doc(doc.id)
          .update({ status: "reviewed" });
        
        await loadAdminDashboard();
      } catch (error) {
        status.textContent =
          "Update failed: " + error.message;
      }
    });
    
    item.appendChild(reviewBtn);
  }
  
  deletionList.appendChild(item);
});
    }

    status.textContent = "Dashboard loaded successfully.";
  } catch (error) {
    console.error("Admin dashboard error:", error);
    status.textContent =
      "Could not load dashboard: " + error.message;
  }
}
let messagingPresenceRefs = [];

function startMessaging() {
  if (!currentUser) return;

  if (unsubscribeChatFriends) unsubscribeChatFriends();

  // Remove old presence listeners
  messagingPresenceRefs.forEach(item => {
    item.ref.off("value", item.handler);
  });
  messagingPresenceRefs = [];

  const friendsContainer = $("messagesFriends");
  if (!friendsContainer) return;

  friendsContainer.textContent = "Loading friends...";

  unsubscribeChatFriends = db.collection("friendships")
    .where("users", "array-contains", currentUser.uid)
    .onSnapshot(async snapshot => {
      friendsContainer.innerHTML = "";

      messagingPresenceRefs.forEach(item => {
        item.ref.off("value", item.handler);
      });
      messagingPresenceRefs = [];

      if (snapshot.empty) {
        friendsContainer.textContent = "No friends available yet.";
        return;
      }

      for (const doc of snapshot.docs) {
        const friendship = doc.data();

        const friendUid = (friendship.users || [])
          .find(uid => uid !== currentUser.uid);

        if (!friendUid) continue;

        try {
          const friendDoc = await db.collection("users")
            .doc(friendUid).get();

          if (!friendDoc.exists) continue;

          const friend = friendDoc.data();

          const button = document.createElement("button");
          button.type = "button";

          // Online/offline indicator
          const dot = document.createElement("span");
          dot.style.display = "inline-block";
          dot.style.width = "10px";
          dot.style.height = "10px";
          dot.style.borderRadius = "50%";
          dot.style.marginRight = "9px";
          dot.style.backgroundColor = "#9ca3af";

          const name = document.createElement("span");
          name.textContent = friend.name || "Learner";

          button.appendChild(dot);
          button.appendChild(name);

          // Listen for live presence updates
          const presenceRef = firebase.database()
            .ref("status/" + friendUid);

          const presenceHandler = statusSnapshot => {
            const status = statusSnapshot.val();
            const online = status && status.state === "online";

            dot.style.backgroundColor =
              online ? "#22c55e" : "#9ca3af";

            dot.title = online ? "Online" : "Offline";
          };

          presenceRef.on("value", presenceHandler);

          messagingPresenceRefs.push({
            ref: presenceRef,
            handler: presenceHandler
          });

          button.addEventListener("click", () => {
            openConversation(friendUid, friend.name || "Learner");
          });

          friendsContainer.appendChild(button);

        } catch (error) {
          console.error("Friend loading error:", error);
        }
      }

    }, error => {
      console.error("Messaging friends error:", error);
      friendsContainer.textContent = "Could not load friends.";
    });
}


// OPEN A PRIVATE CONVERSATION
async function openConversation(friendUid, friendName) {
  if (!currentUser) return;

  const chatId = [currentUser.uid, friendUid]
    .sort()
    .join("_");

  try {
    const chatRef = db.collection("chats").doc(chatId);
    const chatDoc = await chatRef.get();

    if (!chatDoc.exists) {
      await chatRef.set({
        users: [currentUser.uid, friendUid].sort(),
        createdAt: firebase.firestore.FieldValue.serverTimestamp()
      });
    }

    activeChatId = chatId;

    $("messagesHeader").textContent = "Chat with " + friendName;
    $("messagesThread").textContent = "Loading messages...";

    if (unsubscribeChatMessages) {
      unsubscribeChatMessages();
    }

    unsubscribeChatMessages = chatRef.collection("messages")
      .orderBy("createdAt", "asc")
      .onSnapshot(snapshot => {
        const thread = $("messagesThread");
        thread.innerHTML = "";

snapshot.forEach(doc => {
  const message = doc.data();
  
  const item = document.createElement("div");
  const isMine = message.senderUid === currentUser.uid;
  
  item.style.margin = "8px 0";
  item.style.padding = "10px";
  item.style.borderRadius = "10px";
  item.style.maxWidth = "85%";
  item.style.background = isMine ? "#d9fdd3" : "#eeeeee";
  item.style.marginLeft = isMine ? "auto" : "0";
  
  const text = document.createElement("p");
  
  text.textContent =
    (isMine ? "You: " : friendName + ": ") + message.text;
  
  item.appendChild(text);
  
  if (isMine) {
    const deleteBtn = document.createElement("button");
    deleteBtn.textContent = "Delete for Everyone";
    
    deleteBtn.addEventListener("click", async () => {
      const confirmed = confirm(
        "Delete this message for everyone?"
      );
      
      if (!confirmed) return;
      
      try {
        await db.collection("chats")
          .doc(activeChatId)
          .collection("messages")
          .doc(doc.id)
          .delete();
        
        $("messageStatus").textContent =
          "Message deleted for everyone.";
      } catch (error) {
        $("messageStatus").textContent =
          "Could not delete message: " + error.message;
      }
    });
    
    item.appendChild(deleteBtn);
  }
  
  thread.appendChild(item);
});

        thread.scrollTop = thread.scrollHeight;

      }, error => {
        console.error("Message loading error:", error);
        $("messageStatus").textContent =
          "Could not load messages: " + error.message;
      });

    $("messageStatus").textContent = "";

  } catch (error) {
    console.error("Conversation error:", error);
    $("messageStatus").textContent =
      "Could not open conversation: " + error.message;
  }
}

// SEND A MESSAGE
if ($("messageForm")) {
  $("messageForm").addEventListener("submit", async event => {
    event.preventDefault();

    if (!currentUser || !activeChatId) {
      $("messageStatus").textContent =
        "Select a friend before sending a message.";
      return;
    }

    const input = $("messageInput");
    const message = input.value.trim();

    if (!message) return;

    if (message.length > 2000) {
      $("messageStatus").textContent =
        "Messages must be 2000 characters or fewer.";
      return;
    }

    try {
      await db.collection("chats")
        .doc(activeChatId)
        .collection("messages")
        .add({
          senderUid: currentUser.uid,
          text: message,
          createdAt: firebase.firestore.FieldValue.serverTimestamp()
        });

      input.value = "";
      $("messageStatus").textContent = "Message sent.";

    } catch (error) {
      console.error("Message sending error:", error);
      $("messageStatus").textContent =
        "Message failed: " + error.message;
    }
  });
}
// RESEND EMAIL VERIFICATION
const resendBtn = $("resendVerificationBtn");

if (resendBtn) {
  resendBtn.addEventListener("click", async () => {
    if (!currentUser) return;

    try {
      await currentUser.sendEmailVerification();

      $("authMessage").textContent =
        "Verification email sent. Check your inbox.";

    } catch (error) {
      $("authMessage").textContent =
        friendlyError(error);
    }
  });
}
// ACCOUNT DELETION REQUEST
const deleteAccountBtn = $("deleteAccountBtn");

if (deleteAccountBtn) {
  deleteAccountBtn.addEventListener("click", async () => {
    if (!currentUser) {
      showMessage("Please log in first.");
      return;
    }

    const confirmed = confirm(
      "Are you sure you want to request account deletion? An administrator will review your request. Your account will not be deleted immediately."
    );

    if (!confirmed) return;

    try {
      const requestRef = db.collection("deletionRequests")
        .doc(currentUser.uid);

      const existingRequest = await requestRef.get();

      if (existingRequest.exists) {
        showMessage("You have already submitted a deletion request.");
        return; 
      }

      await requestRef.set({
        userId: currentUser.uid,
        status: "pending",
        createdAt: firebase.firestore.FieldValue.serverTimestamp()
      });

      $("deletionRequestStatus").textContent =
  "Your account deletion request has been submitted for review.";
    } catch (error) {
      console.error("Deletion request error:", error);
      $("deletionRequestStatus").textContent =
  "Could not submit request: " + error.message;
    }
  });
}
// FEEDBACK FORM
const feedbackForm = $("feedbackForm");

if (feedbackForm) {
  feedbackForm.addEventListener("submit", async event => {
    event.preventDefault();

    if (!currentUser) {
      $("feedbackStatus").textContent = "Please log in first.";
      return;
    }

    const type = $("feedbackType").value;
    const message = $("feedbackMessage").value.trim();

    if (!message) return;

    try {
      await db.collection("feedback").add({
        userId: currentUser.uid,
        type: type,
        message: message,
        status: "new",
        createdAt: firebase.firestore.FieldValue.serverTimestamp()
      });

      $("feedbackStatus").textContent =
        "Thank you! Your feedback has been submitted.";

      feedbackForm.reset();

    } catch (error) {
      console.error("Feedback error:", error);

      $("feedbackStatus").textContent =
        "Could not submit feedback: " + error.message;
    }
  });
}